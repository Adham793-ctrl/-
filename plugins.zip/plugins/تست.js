import pkg from '@whiskeysockets/baileys';
const { generateWAMessageFromContent, prepareWAMessageMedia } = pkg;

let handler = async (m, { conn }) => {
    try {
        await conn.sendMessage(m.chat, { react: { text: '⚡', key: m.key } });

        const img = 'https://picsum.photos/800/400';

        const media = await prepareWAMessageMedia(
            { image: { url: img } },
            { upload: conn.waUploadToServer }
        );

        const text = `*╭─━─━─━─≪✠≫─━─━─━─╮*
*│*
*│  🎀 نـظـام بـرق 🎀*
*│*
*│  ⚡ تحميلات وادارة الجروب*
*│*
*│  ✅ البوت شغال وبكفاءة عالية*
*│  🤖 نظام ذكي وسريع*
*│*
*│  📢 الاشتراك في القناة إجباري*
*│*
*│  🧾 لاستخدام البوت اكتب: .اوامر*
*│  ⚙️ لتنصيب البوت اكتب: .تنصيب*
*│*
*│  👨‍💻 المطور: ❥ 𝑨𝒅𝒉𝒂𝒎 ❥*
*│*
*╰─━─━─━─≪✠≫─━─━─━─╯*`;

        const message = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            hasMediaAttachment: true,
                            ...media
                        },
                        body: { text },
                        contextInfo: { mentionedJid: [m.sender] },

                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: "cta_url",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "⌈📲╎القناة╎📲⌋",
                                        url: "https://whatsapp.com/channel/0029VbCkwWWEAKWKOCl2Os3E"
                                    })
                                },
                                {
                                    name: "cta_url",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "⌈🚀╎المطور╎🚀⌋",
                                        url: "https://wa.me/201090656418"
                                    })
                                }
                            ]
                        }
                    }
                }
            }
        }, { quoted: m });

        await conn.relayMessage(m.chat, message.message, { messageId: message.key.id });

    } catch (e) {
        console.error(e);
        await conn.reply(m.chat, '❌ حصل خطأ', m);
    }
};

handler.customPrefix = /^\.?(تست|test)$/i;
handler.command = new RegExp;

export default handler;